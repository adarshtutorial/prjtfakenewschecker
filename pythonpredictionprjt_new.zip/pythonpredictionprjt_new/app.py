# importing necessary libraries and functions
import numpy as np
#from flask import Flask, request, jsonify, render_template
from flask import Flask, request,render_template
from collections import Counter
import pickle

app = Flask(__name__) #Initialize the flask App
svc_classifier = pickle.load(open('svc_classifier.pkl', 'rb')) # loading the trained model
vectorizer = pickle.load(open('vectorizer.pkl', 'rb')) # loading the trained model

#@app.route('/',methods=['GET','POST'])

@app.route('/',methods=['POST','GET']) # Homepage
def home():
    if request.method == 'POST':
        text_data=request.form['text_value'].lower()
        word =  Counter(text_data.split())        
        input_len = len(word)
         #to get input word count 
        token_len = 0
        for i in word.keys():
            if i in vectorizer.vocabulary_:
                token_len += 1
     #transform the input text using the vectorize.pkl file
        vectorized_text=vectorizer.transform([text_data])
    

        #predict using the svc_classifier pk l file 
        predicted_value=svc_classifier.predict(vectorized_text)
        return render_template('index.html',post_data=predicted_value[0],word = input_len, token = token_len)
    else:
        return render_template("index.html")
    return render_template('index.html')    
    

if __name__ == "__main__":
    app.run(port=8000)



""" @app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    
    # retrieving values from form
    init_features = [float(x) for x in request.form.values()]
    final_features = [np.array(init_features)]

    prediction = model.predict(final_features) # making prediction


    return render_template('index.html', prediction_text='Predicted Class: {}'.format(prediction)) # rendering the predicted result """


